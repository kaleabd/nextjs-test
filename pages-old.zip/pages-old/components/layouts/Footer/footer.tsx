import React from 'react'

const Footer = () => {
    return (
        <>
            <section className="footer bg-gray-10 border-t">
                <div className="footer-content max-w-3xl mx-auto py-3 text-center">
                    <h1>Krishna</h1>
                </div>
            </section>
        </>
    )
}

export default Footer
